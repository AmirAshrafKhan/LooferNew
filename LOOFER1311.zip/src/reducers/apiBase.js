import axios from "axios";

// const apiBase = axios.create({
//   baseURL: "https://loofer.bellazza.in/api",
// });
const apiBase = "https://loofer.bellazza.in/api"

export default apiBase;
